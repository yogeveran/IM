package assignment1;
	public enum ActionType {
		Diagnose,SendHome,SendToHospital,NoOp;
	}
