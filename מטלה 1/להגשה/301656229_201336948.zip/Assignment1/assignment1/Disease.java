package assignment1;

public enum Disease {
	Cough,Flu,Ebola,Unknown;
}
